import java.util.Scanner;

/**
 * Created by A.Zotov on 21.04.2017.
 */
public class ExtractFIO {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Введите Фамилию Имя и Отчество одной строкой через пробел");
        String strFIO = sc.nextLine();

        String surName = strFIO.substring(0, strFIO.indexOf(" "));
        String strName = strFIO.substring(strFIO.indexOf(" "), strFIO.lastIndexOf(" "));
        String strMiddleName = strFIO.substring(strFIO.lastIndexOf(" "), strFIO.length());

        System.out.println("Фамилия: " + surName);
        System.out.println("Имя: " + strName);
        System.out.println("Отчество: " + strMiddleName);
    }
}
